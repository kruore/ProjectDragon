﻿Title [NYAN dots] 5.0
Cat of Pixelart Animation
Release 2016_06
Scale 32×32 
Type 32

<<Change log>>
Ver5.0
-The number of types of objects has been increased to five.
-Implemented WASD migration with blend tree.

<<terms of use>>
-It is possible to use, regardless of the commercial non-profit.
-You do not need, such as introduction and links.
-I do not write it too fine,Use within the range of common sense.
-However, re-distribution of the material is strictly prohibited.
-Processing use is no problem, but the re-distribution of the material does not allow.

-That act of infringement of my work are all prohibited.
-When you do not know with respect to terms and conditions, please ask a question on Twitter or e-mail.

Twitter:Dotter1973
Mail:liryu1973@yahoo.co.jp
